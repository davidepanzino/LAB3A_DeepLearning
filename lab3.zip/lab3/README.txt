Lab3A readme
To synthesize the fully serial design:
in syn/scr , edit the iter.tcl script to have TOP_NAME FSM.
In the same directory, edit the dc_synthesis.tcl file so that TOP_NAME is FSM as well as change SOURCE_DIR to ../rtl.
Start dc_shell from the exe directory and source iter.tcl with: source ../syn/scr/iter.tcl

To synthesize the fully parallel design:
In syn/scr , edit the iter.tcl script to have TOP_NAME MLP_parallel. 
In the same directory, edit the dc_synthesis.tcl file so that TOP_NAME IS MLP_parallel as well as change SOURCE_DIR to ../rtl_parallel.
Source iter.tcl as described for the fully serial design.
