implementation = ["MLP_parallel"]
attribute = ["cells", "power", "timing"]
indices = [3, 8, 16]
# attribute = ["power"]


for j in range(len(implementation)):
    print("NEW implementation: " + implementation[j])
    for i in range(len(attribute)):
        print("Starting: " + attribute[i])
        # y(3,3) y(3,8) y(3,16) y(8,3) y(8,8) (8,16) (16,3) (16,8) y(16,16)
        for k in range(len(indices)):
            M = indices[k]
            for l in range(len(indices)):
                N = indices[l]
                fileName = (
                    "../syn/rpt/"
                    + implementation[j]
                    + "_N-"
                    + str(N)
                    + ",M-"
                    + str(M)
                    + "_"
                    + attribute[i]
                    + ".txt"
                )

                with open(fileName, "r") as f:
                    for line in f:
                        # look at line in loop
                        lineArr = line.split()

                        # cells
                        if i == 0:
                            if len(lineArr) > 1:
                                if lineArr[0] == "Total" and lineArr[1] != "Dynamic":
                                    finalVal = str(
                                        str(lineArr[-1])
                                        + " " + implementation[j]
                                        + " M:"
                                        + str(M)
                                        + " N:"
                                        + str(N)
                                    )
                                    print(
                                        implementation[i],
                                        "&",
                                        str(N),
                                        "&",
                                        str(M),
                                        "&",
                                        finalVal,
                                        "\\" + "\\",
                                        end="\n",
                                    )
                                    fo = open("data_new.txt", "a")
                                    fo.write(finalVal + "\n")
                                    fo.close
                        # power
                        elif i == 1:
                            if len(lineArr) > 1:
                                if lineArr[0] == "Total" and lineArr[1] != "Dynamic":
                                    finalVal = (
                                        str(lineArr[-2])
                                        + " "
                                        + str(
                                            lineArr[-1]
                                            + " " + implementation[j]
                                            + " M:"
                                            + str(M)
                                            + " N:"
                                            + str(N)
                                        )
                                    )
                                    print(finalVal, end="\n")
                                    fo = open("data_new.txt", "a")
                                    fo.write(finalVal + "\n")
                                    fo.close
                        else:
                            if len(lineArr) > 0:
                                if lineArr[0] == "slack":
                                    finalVal = str(
                                        str(1 / (100 - float(lineArr[-1])) * 10 ** (3))
                                        + " " + implementation[j]
                                        + " M:"
                                        + str(M)
                                        + " N:"
                                        + str(N)
                                    )
                                    print(finalVal, end="\n")
                                    fo = open("data_new.txt", "a")
                                    fo.write(finalVal + "\n")
                                    fo.close


# print(fileName)

